CHUNK_SIZE = 500
CHUNK_OVERLAP = 100

EMBEDDING_MODEL = "nomic-embed-text:latest"
CHAT_MODEL = "llama3:latest"

TOP_K = 3