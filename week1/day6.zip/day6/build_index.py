from rag.loader import load_document
from rag.chunker import chunk_document
from rag.embeddings import embed_chunks
from rag.vector_store import save_vector_store


document_paths = [
    "data/company_policy.txt",
    "data/employee_handbook.txt",
    "data/faq.txt",
]


all_chunks = []


for path in document_paths:
    document = load_document(path)

    chunks = chunk_document(document)

    all_chunks.extend(chunks)


embedded_chunks = embed_chunks(all_chunks)


save_vector_store(
    embedded_chunks,
    "vector_store.json",
)


print(f"Total chunks: {len(embedded_chunks)}")
print("Vector store created successfully.")