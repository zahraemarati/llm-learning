import ollama

from config import CHAT_MODEL
from prompts.system_prompt import SYSTEM_PROMPT
from rag.retriever import retrieve_chunks


def generate_answer(
    question: str,
    vector_store: list[dict],
    conversation_history: list[dict],
) -> dict:

    relevant_chunks = retrieve_chunks(
        question,
        vector_store,
    )

    context_parts = []

    for chunk in relevant_chunks:
        context_parts.append(
            f"""
Source: {chunk["source"]}
Content:
{chunk["text"]}
"""
        )

    context = "\n".join(context_parts)

    user_prompt = f"""
Company Context:

{context}

Current Employee Question:
{question}

Use the company context above to answer the current question.
Use the conversation history only to understand references
and previous discussion.
"""

    messages = [
        {
            "role": "system",
            "content": SYSTEM_PROMPT,
        }
    ]

    messages.extend(conversation_history)

    messages.append({
        "role": "user",
        "content": user_prompt,
    })

    response = ollama.chat(
        model=CHAT_MODEL,
        messages=messages,
    )

    sources = list({
        chunk["source"]
        for chunk in relevant_chunks
    })

    return {
        "answer": response["message"]["content"],
        "sources": sources,
    }