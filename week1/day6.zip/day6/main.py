from assistant.chat import generate_answer
from assistant.memory import ConversationMemory
from rag.vector_store import load_vector_store


vector_store = load_vector_store(
    "vector_store.json"
)

memory = ConversationMemory()


print("AI Company Assistant")
print("Type 'exit' to quit.")
print("Type 'clear' to clear conversation memory.\n")


while True:

    question = input("You: ")

    if question.lower() == "exit":
        print("Goodbye!")
        break

    if question.lower() == "clear":
        memory.clear()
        print("Conversation memory cleared.\n")
        continue

    result = generate_answer(
        question=question,
        vector_store=vector_store,
        conversation_history=memory.get_messages(),
    )

    memory.add_user_message(question)

    memory.add_assistant_message(
        result["answer"]
    )

    print(
        f"\nAssistant: "
        f"{result['answer']}"
    )

    print("\nSources:")

    for source in result["sources"]:
        print(f"- {source}")

    print()