from config import CHUNK_SIZE, CHUNK_OVERLAP


def chunk_document(
    document: dict,
    chunk_size: int = CHUNK_SIZE,
    overlap: int = CHUNK_OVERLAP,
) -> list[dict]:

    text = document["text"]
    source = document["source"]

    paragraphs = [
        paragraph.strip()
        for paragraph in text.split("\n\n")
        if paragraph.strip()
    ]

    chunks = []

    current_chunk = ""
    chunk_id = 0

    for paragraph in paragraphs:

        candidate = (
            f"{current_chunk}\n\n{paragraph}"
            if current_chunk
            else paragraph
        )

        if len(candidate) <= chunk_size:
            current_chunk = candidate

        else:
            if current_chunk:
                chunks.append({
                    "chunk_id": chunk_id,
                    "source": source,
                    "text": current_chunk,
                })

                chunk_id += 1

            overlap_text = (
                current_chunk[-overlap:]
                if current_chunk
                else ""
            )

            current_chunk = (
                f"{overlap_text}\n\n{paragraph}".strip()
            )

    if current_chunk:
        chunks.append({
            "chunk_id": chunk_id,
            "source": source,
            "text": current_chunk,
        })

    return chunks