from pathlib import Path


def load_document(file_path: str) -> dict:
    path = Path(file_path)

    with open(path, "r", encoding="utf-8") as file:
        text = file.read()

    return {
        "text": text,
        "source": path.name,
    }