import json


def save_vector_store(
    chunks: list[dict],
    file_path: str = "vector_store.json",
) -> None:

    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(
            chunks,
            file,
            ensure_ascii=False,
            indent=2,
        )


def load_vector_store(
    file_path: str = "vector_store.json",
) -> list[dict]:

    with open(file_path, "r", encoding="utf-8") as file:
        chunks = json.load(file)

    return chunks