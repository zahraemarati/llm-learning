import ollama

from config import EMBEDDING_MODEL


def create_embedding(text: str) -> list[float]:
    response = ollama.embed(
        model=EMBEDDING_MODEL,
        input=text,
    )

    return response["embeddings"][0]


def embed_chunks(chunks: list[dict]) -> list[dict]:

    texts = [
        chunk["text"]
        for chunk in chunks
    ]

    response = ollama.embed(
        model=EMBEDDING_MODEL,
        input=texts,
    )

    embeddings = response["embeddings"]

    embedded_chunks = []

    for chunk, embedding in zip(chunks, embeddings):

        embedded_chunk = {
            **chunk,
            "embedding": embedding,
        }

        embedded_chunks.append(embedded_chunk)

    return embedded_chunks