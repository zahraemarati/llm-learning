import math

from config import TOP_K
from rag.embeddings import create_embedding


def cosine_similarity(
    vector_a: list[float],
    vector_b: list[float],
) -> float:

    dot_product = sum(
        a * b
        for a, b in zip(vector_a, vector_b)
    )

    magnitude_a = math.sqrt(
        sum(a * a for a in vector_a)
    )

    magnitude_b = math.sqrt(
        sum(b * b for b in vector_b)
    )

    if magnitude_a == 0 or magnitude_b == 0:
        return 0.0

    return dot_product / (
        magnitude_a * magnitude_b
    )


def retrieve_chunks(
    question: str,
    vector_store: list[dict],
    top_k: int = TOP_K,
) -> list[dict]:

    question_embedding = create_embedding(question)

    results = []

    for chunk in vector_store:

        similarity = cosine_similarity(
            question_embedding,
            chunk["embedding"],
        )

        result = {
            **chunk,
            "similarity": similarity,
        }

        results.append(result)

    results.sort(
        key=lambda item: item["similarity"],
        reverse=True,
    )

    return results[:top_k]